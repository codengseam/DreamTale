# 作者意图（author_intent）

> 请填写作者意图全局锚点。
