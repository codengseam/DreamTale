---
name: "主角"
role: "protagonist"
identity: ""
level: ""
color: "#3b6fb3"
---

# 主角

## 性格
（暂无）

## 弧光
（暂无）

## 关系
（暂无）

## 目标
（暂无）
