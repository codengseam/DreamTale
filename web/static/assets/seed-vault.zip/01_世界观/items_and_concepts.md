---
category: "items_and_concepts"
sort_order: 4
---

# items_and_concepts

残剑「问渊」可吸收上古剑骨片段，逐步完整。
每完整一截剑骨，沈砚获得对应剑尊记忆片段与剑意印证。
吸收剑骨需以同等代价交换（伤、业、因果）。
