---
category: "factions"
sort_order: 2
---

# factions

中州：青云宗、玄都观、儒家书院并立。
北荒：无相门隐于暗处。
东海：渊海三王分治。
天地之外：神祇故土，封印之地。
