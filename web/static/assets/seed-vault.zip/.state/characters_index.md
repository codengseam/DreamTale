# 角色索引（characters_index）

> 本文件由 save_state.py 自动生成，禁止手动编辑。

---

## 角色清单

| name | role | location.current | status | last_appeared_ch | filename |
|---|---|---|---|---|---|
| 沈砚 | protagonist | 渊海口 | active | 42 | `protagonist.json` |

---

> 最后更新：2026-07-18（DreamTale Demo 自动生成）
