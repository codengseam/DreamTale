# 全局索引（master_index）

> 问剑长歌 · NovelForge Vault 全局文件索引。

---

## 00_控制面
- project.json — 项目元信息
- author_intent.md — 作者意图（L0 摘要 + L1 详述）
- current_focus.md — 当前创作焦点
- master_index.md — 本文件

## 01_世界观
- core_rules.md — 核心法则（境界体系 + 剑道法则 + 天道封印）
- factions.md — 势力格局
- geography.md — 地理设定
- items_and_concepts.md — 金手指规则

## 02_角色
- protagonist.md — 沈砚（主角）
- 阿箩.md — 阿箩（女主）
- 剑尊问渊.md — 剑尊·问渊（金手指/引路人）
- 裴矩.md — 裴矩（反派）
- 云栖.md — 云栖（挚友）
- 赤蛟王.md — 海族·赤蛟王（卷三反派）

## 03_素材库
- inspirations.md — 灵感碎片
- names_and_places.md — 姓名与地名索引
- plot_devices.md — 情节装置
- writing_techniques.md — 写作技法

## 04_大纲与脉络
- master_outline.md — 总大纲
- story_arc.md — 故事弧光
- hooks_registry.json — 伏笔登记表
- vol_01/ — 卷一大纲 + 章纲
- vol_02/ — 卷二大纲 + 章纲
- vol_03/ — 卷三大纲 + 章纲

## 05_正文
- drafts/ — 草稿
- published/ — 已发布

## .state/
- pipeline.json — 流水线状态
- protagonist.json — 主角状态机
- hooks_registry.json — 伏笔状态（镜像）
- power_curve.json — 金手指强度曲线
- rhythm_curve.json — 节奏曲线
- context_budget.json — 上下文预算
- world_timeline.json — 世界时间线
- chapter_length_history.json — 章节字数历史
- characters_index.md — 角色索引
- state_update_log.json — 状态更新日志
